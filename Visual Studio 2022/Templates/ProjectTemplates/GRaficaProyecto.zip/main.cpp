#include <Gl/glut.h>
int selectedFigure = 0;
int selectedPerspective = 0;

void init() {
	glEnable(GL_DEPTH_TEST);
	glClearColor(0.0, 0.0, 0.0, 0.0);
}

void drawCube() {
	glBegin(GL_QUADS);

	// Cara frontal - Rojo
	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(-1.0, -1.0, 1.0);
	glVertex3f(1.0, -1.0, 1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(-1.0, 1.0, 1.0);

	// Cara posterior - Verde
	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(-1.0, 1.0, -1.0);

	// Cara superior - Azul
	glColor3f(0.0, 0.0, 1.0);
	glVertex3f(-1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(-1.0, 1.0, 1.0);

	// Cara inferior - Amarillo
	glColor3f(1.0, 1.0, 0.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, 1.0);
	glVertex3f(-1.0, -1.0, 1.0);

	// Cara derecha - Rosa
	glColor3f(1.0, 0.0, 1.0);
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(1.0, -1.0, 1.0);

	// Cara izquierda - Cyan
	glColor3f(0.0, 1.0, 1.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(-1.0, 1.0, -1.0);
	glVertex3f(-1.0, 1.0, 1.0);
	glVertex3f(-1.0, -1.0, 1.0);

	glEnd();
}

void drawOctahedron() {
	glBegin(GL_TRIANGLES);
	// Cara 1
	glColor3f(1.0, 0.0, 0.0); // Rojo
	glVertex3f(0.0, 1.0, 0.0);
	glVertex3f(-1.0, 0.0, 0.0);
	glVertex3f(0.0, 0.0, 1.0);

	// Cara 2
	glColor3f(0.0, 1.0, 0.0); // Verde
	glVertex3f(0.0, 1.0, 0.0);
	glVertex3f(0.0, 0.0, 1.0);
	glVertex3f(1.0, 0.0, 0.0);

	// Cara 3
	glColor3f(0.0, 0.0, 1.0); // Azul
	glVertex3f(0.0, 1.0, 0.0);
	glVertex3f(1.0, 0.0, 0.0);
	glVertex3f(0.0, 0.0, -1.0);

	// Cara 4
	glColor3f(1.0, 1.0, 0.0); // Amarillo
	glVertex3f(0.0, 1.0, 0.0);
	glVertex3f(0.0, 0.0, -1.0);
	glVertex3f(-1.0, 0.0, 0.0);

	// Cara 5
	glColor3f(1.0, 0.0, 1.0); // Morado
	glVertex3f(0.0, -1.0, 0.0);
	glVertex3f(-1.0, 0.0, 0.0);
	glVertex3f(0.0, 0.0, 1.0);

	// Cara 6
	glColor3f(0.0, 1.0, 1.0); // Cyan
	glVertex3f(0.0, -1.0, 0.0);
	glVertex3f(0.0, 0.0, 1.0);
	glVertex3f(1.0, 0.0, 0.0);

	// Cara 7
	glColor3f(0.5, 0.5, 0.5); // Gris
	glVertex3f(0.0, -1.0, 0.0);
	glVertex3f(1.0, 0.0, 0.0);
	glVertex3f(0.0, 0.0, -1.0);

	// Cara 8
	glColor3f(1.0, 1.0, 1.0); // Blanco
	glVertex3f(0.0, -1.0, 0.0);
	glVertex3f(0.0, 0.0, -1.0);
	glVertex3f(-1.0, 0.0, 0.0);

	glEnd();
}



void drawTriangularPrism() {
	glBegin(GL_QUADS);
	// Base del prisma triangular
	glColor3f(1.0, 0.0, 0.0); // Rojo
	glVertex3f(-1.0, 0.0, 1.0);
	glVertex3f(1.0, 0.0, 1.0);
	glVertex3f(0.5, 0.0, 0.5);
	glVertex3f(-0.5, 0.0, 0.5);

	// Cara lateral 1
	glColor3f(0.0, 1.0, 0.0); // Verde
	glVertex3f(-1.0, 0.0, 1.0);
	glVertex3f(-0.5, 0.0, 0.5);
	glVertex3f(-0.5, 1.0, 0.5);
	glVertex3f(-1.0, 1.0, 1.0);

	// Cara lateral 2
	glColor3f(0.0, 0.0, 1.0); // Azul
	glVertex3f(-0.5, 0.0, 0.5);
	glVertex3f(0.5, 0.0, 0.5);
	glVertex3f(0.5, 1.0, 0.5);
	glVertex3f(-0.5, 1.0, 0.5);

	// Cara lateral 3
	glColor3f(1.0, 1.0, 0.0); // Amarillo
	glVertex3f(1.0, 0.0, 1.0);
	glVertex3f(0.5, 0.0, 0.5);
	glVertex3f(0.5, 1.0, 0.5);
	glVertex3f(1.0, 1.0, 1.0);

	// Cara superior
	glColor3f(1.0, 0.0, 1.0); // Morado
	glVertex3f(-0.5, 1.0, 0.5);
	glVertex3f(0.5, 1.0, 0.5);
	glVertex3f(0.5, 1.0, 0.5);
	glVertex3f(-1.0, 1.0, 1.0);

	glEnd();
}

void drawSelectedFigure() {
	switch (selectedFigure) {
	case 1: // Cubo
		drawCube();
		break;
	case 2:
		drawOctahedron();
		break;
	case 3: // Prisma triangular
		drawTriangularPrism();
		break;
	default:
		break;
	}
}

void display() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	switch (selectedPerspective) {
	case 1: // Perspectiva frontal
		gluLookAt(3.0, 3.0, 3.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		break;
	case 2: // Perspectiva oblicua
		gluLookAt(3.0, 3.0, 3.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0);
		break;
	case 3: // Perspectiva a�rea
		gluLookAt(0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -1.0);
		break;
	default: // Perspectiva frontal por defecto
		gluLookAt(-5.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
		break;
	}

	drawSelectedFigure();

	glFlush();
	glutSwapBuffers();
}

void reshape(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat)w / (GLfloat)h, 1.0, 100.0);
	glMatrixMode(GL_MODELVIEW);
}

void figureMenu(int value) {
	selectedFigure = value;
	glutPostRedisplay();
}

void perspectiveMenu(int value) {
	selectedPerspective = value;
	glutPostRedisplay();
}

void createMenus() {

	int figureSubMenu = glutCreateMenu(figureMenu);
	glutAddMenuEntry("Cubo", 1);
	glutAddMenuEntry("Octaedro", 2);
	glutAddMenuEntry("Prisma triangular", 3);


	int perspectiveSubMenu = glutCreateMenu(perspectiveMenu);
	glutAddMenuEntry("Perspectiva frontal", 1);
	glutAddMenuEntry("Perspectiva oblicua", 2);
	glutAddMenuEntry("Perspectiva a�rea", 3);


	glutCreateMenu(NULL);
	glutAddSubMenu("Seleccionar figura", figureSubMenu);
	glutAddSubMenu("Seleccionar perspectiva", perspectiveSubMenu);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("Perspectiva Conica Puntos de Fuga");
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);

	createMenus();

	glutMainLoop();
	return 0;
}